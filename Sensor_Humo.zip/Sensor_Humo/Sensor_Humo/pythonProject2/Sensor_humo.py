import zmq
import time
import random
import threading

def sensor_humo():
    context = zmq.Context()
    socket = context.socket(zmq.PUSH)
    socket.connect("tcp://localhost:5555")

    while True:
        detectar_humo = random.random() < 0.1  # 10% de probabilidad de detectar humo
        socket.send_json({"tipo": "humo", "valor": detectar_humo})
        time.sleep(3)

if __name__ == "__main__":
    sensor_humo_thread = threading.Thread(target=sensor_humo)
    sensor_humo_thread.start()
    sensor_humo_thread.join()
