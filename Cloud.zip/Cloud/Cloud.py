import zmq
import threading
import time

def cloud_layer():
    context = zmq.Context()
    socket = context.socket(zmq.REQ)
    primary_proxy = "tcp://localhost:5560"
    backup_proxy = "tcp://localhost:5561"
    socket.connect(primary_proxy)

    alarm_storage = []
    is_primary = True

    while True:
        try:
            # Perform health check
            socket.send_json({"command": "health_check"})
            health_status = socket.recv_json()
            print(f"Health check status: {health_status}")

            if health_status.get("status") != "alive":
                raise Exception("Proxy not responding")

            # Fetch data from proxy
            socket.send_json({"command": "fetch"})
            response = socket.recv_json()
            print(f"Data received from proxy: {response}")

            if "alert" in response:
                alarm_storage.append(response)

            time.sleep(5)  # Realizar el chequeo y fetch cada 5 segundos

        except:
            print("Switching to backup proxy...")
            socket.close()
            context = zmq.Context()
            socket = context.socket(zmq.REQ)
            if is_primary:
                socket.connect(backup_proxy)
                is_primary = False
            else:
                socket.connect(primary_proxy)
                is_primary = True

thread = threading.Thread(target=cloud_layer)
thread.start()
