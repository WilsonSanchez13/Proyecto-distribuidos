import zmq
import threading

def actuador():
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    socket.connect("tcp://localhost:5558")
    socket.setsockopt_string(zmq.SUBSCRIBE, '')

    while True:
        message = socket.recv_json()
        if message.get("tipo") == "humo" and message.get("valor") == True:
            print("Aspersor activado: se ha detectado humo")

thread = threading.Thread(target=actuador)
thread.start()
