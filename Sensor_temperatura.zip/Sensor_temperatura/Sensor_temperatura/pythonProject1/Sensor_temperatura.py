import zmq
import time
import random
import threading

def sensor_temperatura():
    context = zmq.Context()
    socket = context.socket(zmq.PUSH)
    socket.connect("tcp://localhost:5555")

    while True:
        temperatura = random.randint(11, 30)  # Simula temperaturas en el rango normal
        socket.send_json({"tipo": "temperatura", "valor": temperatura})
        time.sleep(6)

if __name__ == "__main__":
    sensor_temperatura_thread = threading.Thread(target=sensor_temperatura)
    sensor_temperatura_thread.start()
    sensor_temperatura_thread.join()
