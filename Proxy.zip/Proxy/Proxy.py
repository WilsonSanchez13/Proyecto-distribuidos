import zmq
import threading
from collections import deque


def proxy():
    context = zmq.Context()
    socket_receptor = context.socket(zmq.PULL)
    socket_receptor.bind("tcp://*:5555")

    socket_actuador = context.socket(zmq.PUB)
    socket_actuador.bind("tcp://*:5558")

    socket_cloud = context.socket(zmq.REP)
    socket_cloud.bind("tcp://*:5560")

    temperaturas = deque(maxlen=10)
    humedades = deque(maxlen=10)

    while True:
        message = socket_receptor.recv_json()
        tipo_sensor = message["tipo"]
        valor = message["valor"]

        if tipo_sensor == "temperatura":
            temperaturas.append(valor)
            promedio_temperatura = sum(temperaturas) / len(temperaturas)
            print(f"Promedio de temperatura: {promedio_temperatura}°C")
            if promedio_temperatura > 30:
                print("Alerta: Temperatura alta detectada")

        elif tipo_sensor == "humedad":
            humedades.append(valor)
            promedio_humedad = sum(humedades) / len(humedades)
            print(f"Promedio de humedad: {promedio_humedad}%")
            if promedio_humedad < 70:
                print("Alerta: Humedad baja detectada")

        elif tipo_sensor == "humo" and valor:
            print("Alerta: Humo detectado, activando aspersor")
            socket_actuador.send_json({"tipo": "humo", "valor": True})

        # Responder a la capa cloud
        try:
            request = socket_cloud.recv_json(flags=zmq.NOBLOCK)
            if request.get('command') == 'fetch':
                socket_cloud.send_json({"status": "ok", "data": message})
            elif request.get('command') == 'health_check':
                socket_cloud.send_json({"status": "alive"})
        except zmq.Again:
            pass  # No new requests


thread = threading.Thread(target=proxy)
thread.start()
