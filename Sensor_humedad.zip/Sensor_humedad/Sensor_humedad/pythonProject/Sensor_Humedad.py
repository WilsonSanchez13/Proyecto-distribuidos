import zmq
import time
import random
import threading

def sensor_humedad():
    context = zmq.Context()
    socket = context.socket(zmq.PUSH)
    socket.connect("tcp://localhost:5555")

    while True:
        humedad = random.randint(70, 100)  # Simula humedad dentro del rango normal
        socket.send_json({"tipo": "humedad", "valor": humedad})
        time.sleep(5)

if __name__ == "__main__":
    sensor_humedad_thread = threading.Thread(target=sensor_humedad)
    sensor_humedad_thread.start()
    sensor_humedad_thread.join()
